# ECS Flavor Selection

**Always discover flavors dynamically before recommending a specific flavor name.** Flavor availability varies by region and changes over time.

## Step 1: List available flavors
hcloud ECS ListFlavors --cli-region=<region> --cli-output=json

## Step 2: Filter by scenario

| Scenario | Look for | Preference |
|----------|----------|------------|
| Web app / microservices | General-purpose families (ac, s, sn) | 2-4 vCPU, 4-8 GB RAM |
| Database / big data | Memory-optimized families (m, r) | 4-8 vCPU, 16-64 GB RAM |
| AI inference / training | GPU families (g, p) | 8+ vCPU, 64+ GB RAM |
| HPC / high throughput | High-IO families (h, ir, i) | 8+ vCPU, local SSD |

## Step 3: Match spec from ListFlavors output

Common naming pattern: `<family><gen>.<type>x<ratio>`
- `ac6.2xlarge.2` = ac6 family, 2xlarge (8 vCPU), ratio 2 (vCPU:RAM = 1:2 → 16 GB)

## Do Not Hardcode

Flavor family names are region-dependent. Example discrepancies seen in testing:
- cn-south-1: ac6/ac7/kc/r-c7e (s6/m6/g6 NOT available)
- Other regions may have s6/m6/g6 families

Always run ListFlavors and pick from actual results.
