import { planHcloudCommand, runHcloud } from './hcloud-cli.mjs';
import { classifyTextCommand, redactSecrets } from './safety-policy.mjs';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SKILLS_ROOT = join(__dirname, '..', 'skills');

export const TOOL_DEFINITIONS = [
  {
    name: 'huaweicloud_check_cli',
    description: 'Check whether Huawei Cloud KooCLI hcloud is installed. Returns redacted output.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'huaweicloud_plan_cli_command',
    description: 'Classify and plan a Huawei Cloud hcloud command without executing it.',
    inputSchema: {
      type: 'object',
      required: ['args'],
      properties: {
        args: {
          type: 'array',
          items: { type: 'string' },
          description: 'hcloud arguments, excluding the hcloud executable.',
        },
        allowWrites: {
          type: 'boolean',
          description: 'Only true after explicit user approval for this exact operation.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_run_readonly_command',
    description: 'Run a read-only hcloud command through the toolkit safety policy and redact output.',
    inputSchema: {
      type: 'object',
      required: ['args'],
      properties: {
        args: {
          type: 'array',
          items: { type: 'string' },
        },
        timeoutMs: {
          type: 'number',
          description: 'Optional timeout in milliseconds. Defaults to 60000.',
        },
        maxRetries: {
          type: 'number',
          description: 'Optional retry count for transient network errors. Defaults to 1.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_list_operations',
    description: 'List KooCLI operations for a Huawei Cloud service by running local/read-only hcloud <Service> --help.',
    inputSchema: {
      type: 'object',
      required: ['service'],
      properties: {
        service: {
          type: 'string',
          description: 'KooCLI service name, such as ECS, VPC, IMS, OBS, RDS, or CDN.',
        },
        timeoutMs: {
          type: 'number',
          description: 'Optional timeout in milliseconds. Defaults to 60000.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_run_approved_command',
    description: 'Run a write-capable hcloud command only after the exact command has been shown and explicitly approved by the user.',
    inputSchema: {
      type: 'object',
      required: ['args', 'approvedCommand', 'approvedByUser'],
      properties: {
        args: {
          type: 'array',
          items: { type: 'string' },
          description: 'hcloud arguments, excluding the hcloud executable.',
        },
        approvedCommand: {
          type: 'string',
          description: 'The exact command string previously shown to the user.',
        },
        approvedByUser: {
          type: 'boolean',
          description: 'Must be true only after the user explicitly approves this exact command.',
        },
        timeoutMs: {
          type: 'number',
          description: 'Optional timeout in milliseconds. Defaults to 60000.',
        },
        maxRetries: {
          type: 'number',
          description: 'Optional retry count for transient network errors. Defaults to 1.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_show_profile_redacted',
    description: 'Inspect a KooCLI profile through hcloud configure show and return only redacted output.',
    inputSchema: {
      type: 'object',
      properties: {
        profile: {
          type: 'string',
          description: 'Optional KooCLI profile name.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_service_catalog',
    description: 'Return the recommended capability sources for Huawei Cloud agent tasks.',
    inputSchema: {
      type: 'object',
      properties: {
        intent: {
          type: 'string',
          description: 'Developer intent to route, such as deploy app, use API, debug error, or inspect resources.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_explain_error',
    description: 'Explain a Huawei Cloud CLI, API, SDK, or agent workflow error and suggest next diagnostic steps.',
    inputSchema: {
      type: 'object',
      properties: {
        service: { type: 'string' },
        errorCode: { type: 'string' },
        message: { type: 'string' },
        requestId: { type: 'string' },
      },
    },
  },
  {
    name: 'huaweicloud_search_docs',
    description: 'Search across Huawei Cloud SKILL.md files and local documentation. Returns top 10 relevant results with source, name, snippet, and relevance score. Use when the agent needs to discover which skill covers a topic, or when uncertain about API parameters, quotas, or limitations.',
    inputSchema: {
      type: 'object',
      required: ['query'],
      properties: {
        query: { type: 'string', description: 'Search query across skill descriptions and documentation.' },
        topic: { type: 'string', description: 'Optional filter: all | ecs | obs | vpc | iam | rds | cce | modelarts | dew. Defaults to all.' },
      },
    },
  },
  {
    name: 'huaweicloud_retrieve_skill',
    description: 'Retrieve a full SKILL.md by skill name. Returns the complete skill content plus list of reference files. Use when the agent has identified which skill to load and needs the full procedure.',
    inputSchema: {
      type: 'object',
      required: ['name'],
      properties: {
        name: { type: 'string', description: 'Skill name, e.g., huaweicloud-core, huawei-ecs, huawei-obs.' },
      },
    },
  },
  {
    name: 'huaweicloud_list_regions',
    description: 'List available Huawei Cloud regions. Returns region IDs, display names, and endpoints. Use when the agent needs to discover available regions before creating resources.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'huaweicloud_get_regional_availability',
    description: 'Check if a specific Huawei Cloud service is available in a target region. Use before creating resources to prevent failures from regional unavailability.',
    inputSchema: {
      type: 'object',
      required: ['service', 'region'],
      properties: {
        service: { type: 'string', description: 'Service name: ecs, obs, rds, gaussdb, cce, modelarts, functiongraph, etc.' },
        region: { type: 'string', description: 'Region ID: cn-south-1, cn-north-4, ap-southeast-3, etc.' },
      },
    },
  },
];

export async function callTool(name, args = {}) {
  switch (name) {
    case 'huaweicloud_check_cli':
      return runVersionCheck();
    case 'huaweicloud_plan_cli_command':
      return planHcloudCommand(args.args || [], { allowWrites: args.allowWrites === true });
    case 'huaweicloud_run_readonly_command':
      return runHcloud(args.args || [], {
        timeoutMs: args.timeoutMs,
        maxRetries: args.maxRetries,
      });
    case 'huaweicloud_list_operations':
      return listOperations(args.service, { timeoutMs: args.timeoutMs });
    case 'huaweicloud_run_approved_command':
      return runApprovedCommand(args);
    case 'huaweicloud_show_profile_redacted':
      return showProfileRedacted(args.profile);
    case 'huaweicloud_service_catalog':
      return serviceCatalog(args.intent);
    case 'huaweicloud_search_docs':
      return searchDocs(args.query || '', args.topic || 'all');
    case 'huaweicloud_retrieve_skill':
      return retrieveSkill(args.name || '');
    case 'huaweicloud_list_regions':
      return listRegions();
    case 'huaweicloud_get_regional_availability':
      return getRegionalAvailability(args.service || '', args.region || '');
        case 'huaweicloud_explain_error':
      return explainError(args);
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

export async function runVersionCheck(options = {}) {
  const result = await runHcloud(['version'], {
    ...options,
    maxRetries: options.maxRetries ?? 0,
  });
  const errorText = result.error || result.stderr || '';
  const isSpawnError = /ENOENT|SPAWN_ERROR/i.test(errorText) || result.code === 'SPAWN_ERROR';
  return {
    installed: result.ok,
    errorCode: isSpawnError ? 'HCLOUD_NOT_FOUND' : undefined,
    output: result.ok ? result.stdout : errorText,
    nextStep: result.ok
      ? 'Use huaweicloud_show_profile_redacted to inspect the active KooCLI profile safely.'
      : isSpawnError
        ? 'hcloud executable not found. If hcloud is already installed, set the HCLOUD_BIN environment variable to the full path of hcloud (e.g., C:\\Users\\sunzy\\hcloud\\hcloud.exe on Windows, or /usr/local/bin/hcloud on Linux/macOS). Then restart the agent session. Otherwise, install KooCLI from https://support.huaweicloud.com/qs-hcli/hcli_02_003.html.'
        : 'Install Huawei Cloud KooCLI from https://support.huaweicloud.com/qs-hcli/hcli_02_003.html. If hcloud is not on PATH, set HCLOUD_BIN to the hcloud executable path. Configure credentials outside the agent conversation.',
  };
}

async function showProfileRedacted(profile) {
  const args = ['configure', 'show'];
  if (profile) {
    args.push('--cli-profile', String(profile));
  }
  const result = await runHcloud(args, { allowWrites: false, allowCredentialRead: true }).catch((error) => ({
    ok: false,
    blocked: true,
    reason: error.message,
  }));
  if (result.blocked) {
    return {
      ok: false,
      blockedByPolicy: true,
      reason: result.reason,
      safeAlternative: 'Use huaweicloud_show_profile_redacted so profile output is returned through the redaction pipeline.',
    };
  }
  return {
    ok: result.ok,
    note: 'Profile information was returned through the toolkit redaction pipeline.',
    result: redactSecrets(result),
  };
}

async function listOperations(service, options = {}) {
  const serviceName = String(service || '').trim();
  if (!/^[A-Za-z][A-Za-z0-9-]{1,63}$/.test(serviceName)) {
    throw new Error('service must be a KooCLI service name such as ECS, VPC, IMS, OBS, RDS, or CDN.');
  }
  const result = await runHcloud([serviceName, '--help'], {
    timeoutMs: options.timeoutMs,
    maxRetries: 0,
  });
  return {
    service: serviceName,
    command: `hcloud ${serviceName} --help`,
    selectionRule: 'Use this help text to select the exact KooCLI operation name before planning any service command.',
    examples: {
      listEcsInstances: 'ECS ListServersDetails',
      createEcsInstance: 'ECS CreateServers',
      showImage: 'IMS GlanceShowImage',
    },
    result,
  };
}

async function runApprovedCommand(args = {}) {
  if (args.approvedByUser !== true) {
    throw new Error('approvedByUser must be true after explicit user approval for this exact command.');
  }
  const plan = planHcloudCommand(args.args || [], { allowWrites: true });
  if (String(args.approvedCommand || '') !== plan.command) {
    throw new Error('approvedCommand must exactly match the planned hcloud command.');
  }
  return runHcloud(args.args || [], {
    allowWrites: true,
    timeoutMs: args.timeoutMs,
    maxRetries: args.maxRetries,
  });
}

function serviceCatalog(intent = '') {
  return {
    intent,
    recommendedOrder: [
      'Huawei Cloud Skills for task-specific workflows and examples',
      'KooCLI hcloud for local authenticated operations and quick inspection',
      'Huawei Cloud API documentation for exact request and response contracts',
      'Huawei Cloud SDKs for application code integration',
      'Huawei Cloud MCP when an official or approved server is available',
      'Terraform Provider only when IaC reviewability and repeatability are important',
    ],
    ruleOfThumb: {
      skills: 'Start here when the user describes a scenario or wants a guided workflow.',
      cli: 'Use for local diagnostics, read-only inspection, and commands the user can review.',
      api: 'Use for exact service contract, region endpoint, project_id, pagination, and error codes.',
      sdk: 'Use when writing application code that calls Huawei Cloud services.',
      mcp: 'Prefer approved MCP tools when available because tools can carry structured schemas.',
      terraform: 'Keep low priority in V1; suggest it for reviewed infrastructure changes, not quick diagnosis.',
    },
  };
}

function explainError({ service = 'unknown', errorCode = '', message = '', requestId = '' } = {}) {
  const combined = `${errorCode} ${message}`.toLowerCase();
  const suggestions = [];

  if (/auth|token|credential|ak|sk|401|403|unauthorized|forbidden/i.test(combined)) {
    suggestions.push('Check KooCLI profile, region, project_id, and IAM permissions without printing secrets.');
  }
  if (/region|endpoint|project/i.test(combined)) {
    suggestions.push('Confirm the service endpoint, region, and project_id match the target resource.');
  }
  if (/quota|limit|insufficient/i.test(combined)) {
    suggestions.push('Check quota and resource limits before retrying a create or scale operation.');
  }
  if (/not.?found|404/i.test(combined)) {
    suggestions.push('List resources in the same region/project and verify the resource identifier.');
  }
  if (!suggestions.length) {
    suggestions.push('Collect service name, operation, region, project_id, request_id, and the full redacted error message.');
  }

  return {
    service,
    errorCode,
    requestId,
    suggestions,
  };
}

async function searchDocs(query, topic = 'all') {
  const q = String(query || '').toLowerCase();
  const results = [];
  try {
    if (existsSync(SKILLS_ROOT)) {
      const dirs = readdirSync(SKILLS_ROOT, { withFileTypes: true })
        .filter((d) => d.isDirectory())
        .map((d) => d.name);
      for (const dir of dirs) {
        const skillPath = join(SKILLS_ROOT, dir, 'SKILL.md');
        if (!existsSync(skillPath)) continue;
        const content = readFileSync(skillPath, 'utf8');
        const frontmatter = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
        let description = '';
        let name = dir;
        if (frontmatter) {
          const fm = frontmatter[1];
          const nameMatch = fm.match(/^name:\s*(.+)$/m);
          if (nameMatch) name = nameMatch[1].trim();
          const descMatch = fm.match(/^description:\s*(.+)$/m);
          if (descMatch) description = descMatch[1].trim();
        }
        if (topic !== 'all' && !name.includes(topic) && !description.toLowerCase().includes(topic)) continue;
        const relevance =
          (description.toLowerCase().includes(q) ? 3 : 0) +
          (name.toLowerCase().includes(q) ? 2 : 0) +
          (content.toLowerCase().includes(q) ? 1 : 0);
        if (relevance > 0) {
          results.push({
            source: "skills/" + dir + "/SKILL.md",
            name,
            snippet: description.substring(0, 200),
            relevance,
          });
        }
      }
    }
  } catch (err) {
    return { ok: false, error: err.message, results: [] };
  }
  results.sort((a, b) => b.relevance - a.relevance);
  return { ok: true, query: q, topic, count: results.length, results: results.slice(0, 10) };
}

async function retrieveSkill(name) {
  const skillName = String(name || '').trim();
  if (!skillName) return { ok: false, error: 'Skill name is required.' };
  const skillPath = join(SKILLS_ROOT, skillName, 'SKILL.md');
  if (!existsSync(skillPath)) {
    const dirs = existsSync(SKILLS_ROOT)
      ? readdirSync(SKILLS_ROOT, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name)
      : [];
    return { ok: false, error: 'Skill "' + skillName + '" not found. Available: ' + dirs.join(', ') };
  }
  const content = readFileSync(skillPath, 'utf8');
  const references = [];
  const refDir = join(SKILLS_ROOT, skillName, 'references');
  if (existsSync(refDir)) readdirSync(refDir).forEach((f) => references.push(f));
  const frontmatter = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  let version = 1, description = '';
  if (frontmatter) {
    const fm = frontmatter[1];
    const vm = fm.match(/^version:\s*(.+)$/m);
    if (vm) version = vm[1].trim();
    const dm = fm.match(/^description:\s*(.+)$/m);
    if (dm) description = dm[1].trim();
  }
  return { ok: true, name: skillName, version, description, content, references };
}

async function listRegions() {
  const result = await runHcloud(['iam', 'list-regions'], { timeoutMs: 30000, maxRetries: 0 })
    .catch((err) => ({ ok: false, error: err.message }));
  if (!result.ok) {
    return {
      ok: false,
      error: result.error || 'Failed to list regions.',
      fallback: 'Check https://developer.huaweicloud.com/endpoint for available regions.',
    };
  }
  let regions = [];
  try {
    const parsed = typeof result.stdout === 'string' ? JSON.parse(result.stdout) : result.stdout;
    const rawRegions = parsed.regions || [];
    regions = rawRegions.map((r) => ({
      id: r.id,
      description: r.description || r.names,
      type: r.type,
      locales: r.locales,
    }));
  } catch {
    regions = [{ raw: String(result.stdout).substring(0, 1000) }];
  }
  regions.sort((a, b) => String(a.id || '').localeCompare(String(b.id || '')));
  return { ok: true, count: regions.length, regions };
}

async function getRegionalAvailability(service, region) {
  const svc = String(service || '').toLowerCase().trim();
  const reg = String(region || '').toLowerCase().trim();
  if (!svc || !reg) return { ok: false, error: 'Both service and region are required.' };
  const known = {
    ecs: ['cn-south-1','cn-north-4','cn-east-3','cn-east-2','ap-southeast-3','ap-southeast-2','ap-southeast-1','af-south-1'],
    obs: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3','ap-southeast-1'],
    vpc: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3','ap-southeast-1'],
    iam: ['global'],
    rds: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3','ap-southeast-1'],
    gaussdb: ['cn-south-1','cn-north-4','cn-east-3'],
    cce: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3'],
    modelarts: ['cn-south-1','cn-north-4','cn-east-3'],
    functiongraph: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3'],
    dew: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3'],
    smn: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3'],
    ces: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3'],
    cts: ['cn-south-1','cn-north-4','cn-east-3','ap-southeast-3'],
  };
  const found = known[svc] || [];
  const available = found.includes(reg) || found.includes('global');
  return {
    ok: true, service: svc, region: reg, available,
    note: available
      ? svc + ' is available in ' + reg + '.'
      : svc + ' availability in ' + reg + ' could not be confirmed. Verify at https://developer.huaweicloud.com/endpoint.',
  };
}

export function classifyRawCommand(command) {
  return classifyTextCommand(command);
}
