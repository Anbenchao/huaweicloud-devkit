#!/usr/bin/env node

import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir, platform } from 'node:os';
import { createInterface } from 'node:readline';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PLUGIN_ROOT = resolve(__dirname, '..');
const PACKAGE_ROOT = resolve(PLUGIN_ROOT, '..', '..');

const BANNER = `
╔══════════════════════════════════════════════╗
║     HuaweiCloud DevKit v0.1.0              ║
║     https://github.com/huaweicloud-mate   ║
╚══════════════════════════════════════════════╝
`;

function configDir(target = 'opencode') {
  const home = homedir();
  if (platform() === 'win32') {
    return join(home, '.config', target);
  }
  return join(home, '.config', target);
}

function opencodeSkillsDir() { return join(configDir('opencode'), 'skills'); }
function opencodeCommandsDir() { return join(configDir('opencode'), 'commands'); }
function opencodePluginsDir() { return join(configDir('opencode'), 'huaweicloud-plugins'); }
function opencodeConfigFile() { return join(configDir('opencode'), 'opencode.json'); }

function checkNode() {
  const v = process.versions.node.split('.').map(Number);
  if (v[0] < 20) {
    console.error(`\x1b[31mNode.js >= 20 required (current: ${process.version})\x1b[0m`);
    process.exit(1);
  }
  console.log(`  Node.js ${process.version} \x1b[32mOK\x1b[0m`);
}

function copyDir(src, dest) {
  if (!existsSync(src)) return;
  mkdirSync(dest, { recursive: true });
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    const s = join(src, entry.name);
    const d = join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(s, d);
    } else {
      copyFileSync(s, d);
    }
  }
}

function removeIfExists(p) {
  if (existsSync(p)) {
    rmSync(p, { recursive: true, force: true });
    return true;
  }
  return false;
}

function updateOpenCodeConfig(pluginDir) {
  const configPath = opencodeConfigFile();
  let config = {};
  if (existsSync(configPath)) {
    try { config = JSON.parse(readFileSync(configPath, 'utf8')); } catch {}
  }

  const mcpPath = join(pluginDir, 'src', 'mcp-server.mjs').replace(/\\/g, '/');
  config.mcpServers = config.mcpServers || {};
  config.mcpServers.huaweicloud = {
    type: 'local',
    command: 'node',
    args: [mcpPath],
    enabled: true,
  };

  writeFileSync(configPath, JSON.stringify(config, null, 2));
  console.log(`  OpenCode MCP config updated: ${configPath}`);
}

function removeOpenCodeConfig() {
  const configPath = opencodeConfigFile();
  if (!existsSync(configPath)) return;
  let config = {};
  try { config = JSON.parse(readFileSync(configPath, 'utf8')); } catch { return; }
  if (!config.mcpServers || !config.mcpServers.huaweicloud) return;
  delete config.mcpServers.huaweicloud;
  if (Object.keys(config.mcpServers).length === 0) delete config.mcpServers;
  writeFileSync(configPath, JSON.stringify(config, null, 2));
  console.log(`  OpenCode MCP config cleaned: ${configPath}`);
}

let confirmed = false;
async function confirm(msg) {
  if (confirmed) return true;
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((ok) => {
    rl.question(`${msg} [y/N] `, (a) => {
      rl.close();
      ok(a.toLowerCase() === 'y' || a.toLowerCase() === 'yes');
    });
  });
}

async function cmdInstall() {
  console.log(BANNER);
  console.log('Installing HuaweiCloud DevKit for OpenCode...\n');

  checkNode();

  const skillsSrc = join(PLUGIN_ROOT, 'skills');
  const commandsSrc = join(PACKAGE_ROOT, 'integrations', 'opencode', 'commands');
  const srcDir = join(PLUGIN_ROOT, 'src');
  const safetyDir = join(PLUGIN_ROOT, 'safety');
  const pluginDest = opencodePluginsDir();

  console.log('Copying files...');
  copyDir(skillsSrc, opencodeSkillsDir());
  console.log(`  Skills -> ${opencodeSkillsDir()}`);
  copyDir(commandsSrc, opencodeCommandsDir());
  console.log(`  Commands -> ${opencodeCommandsDir()}`);
  copyDir(srcDir, join(pluginDest, 'src'));
  console.log(`  MCP Server -> ${join(pluginDest, 'src')}`);
  copyDir(safetyDir, join(pluginDest, 'safety'));
  console.log(`  Safety Policy -> ${join(pluginDest, 'safety')}`);

  updateOpenCodeConfig(pluginDest);

  console.log(`\n\x1b[32mInstallation complete!\x1b[0m`);
  console.log('\nTo verify, restart OpenCode and try: @huaweicloud-core');
}

async function cmdUninstall() {
  console.log(BANNER);
  console.log('Uninstalling HuaweiCloud DevKit...\n');

  const skills = opencodeSkillsDir();
  let removed = 0;

  // Remove only huawei* skills, not all skills
  if (existsSync(skills)) {
    for (const entry of readdirSync(skills, { withFileTypes: true })) {
      if (entry.name.startsWith('huawei')) {
        removeIfExists(join(skills, entry.name));
        removed++;
      }
    }
    console.log(`  Removed ${removed} skills`);
  }

  if (removeIfExists(opencodePluginsDir())) {
    console.log('  Removed MCP server and safety policy');
  }

  removeOpenCodeConfig();

  console.log(`\n\x1b[32mUninstall complete.\x1b[0m`);
}

async function cmdStatus() {
  console.log(BANNER);
  console.log('HuaweiCloud DevKit Status\n');

  const pluginDir = opencodePluginsDir();
  const skillsDir = opencodeSkillsDir();

  console.log('Installation:');
  console.log(`  MCP Server: ${existsSync(join(pluginDir, 'src', 'mcp-server.mjs')) ? '\x1b[32mInstalled\x1b[0m' : '\x1b[31mNot installed\x1b[0m'}`);
  console.log(`  Safety Policy: ${existsSync(join(pluginDir, 'safety', 'policy.json')) ? '\x1b[32mInstalled\x1b[0m' : '\x1b[31mNot installed\x1b[0m'}`);

  let skillCount = 0;
  if (existsSync(skillsDir)) {
    skillCount = readdirSync(skillsDir, { withFileTypes: true })
      .filter((d) => d.isDirectory() && d.name.startsWith('huawei')).length;
  }
  console.log(`  Skills: ${skillCount > 0 ? `\x1b[32m${skillCount} installed\x1b[0m` : '\x1b[31mNot installed\x1b[0m'}`);

  const configPath = opencodeConfigFile();
  if (existsSync(configPath)) {
    try {
      const config = JSON.parse(readFileSync(configPath, 'utf8'));
      console.log(`  OpenCode MCP: ${config.mcpServers?.huaweicloud ? '\x1b[32mConfigured\x1b[0m' : '\x1b[31mNot configured\x1b[0m'}`);
    } catch {
      console.log(`  OpenCode MCP: \x1b[31mConfig file invalid\x1b[0m`);
    }
  } else {
    console.log(`  OpenCode MCP: \x1b[31mConfig file not found\x1b[0m`);
  }

  console.log('\nEnvironment:');
  console.log(`  Node.js: ${process.version}`);
  console.log(`  Platform: ${platform()}`);
  console.log(`  Config root: ${configDir('opencode')}`);
}

async function cmdUpdate() {
  console.log(BANNER);
  console.log('Updating HuaweiCloud DevKit...\n');

  const pluginDir = opencodePluginsDir();
  if (!existsSync(join(pluginDir, 'src', 'mcp-server.mjs'))) {
    console.log('\x1b[33mNot installed. Use "install" command first.\x1b[0m');
    return;
  }

  await cmdUninstall();
  console.log('');
  await cmdInstall();
}

async function cmdReinstall() {
  console.log(BANNER);
  if (!(await confirm('This will remove and reinstall all HuaweiCloud DevKit files. Continue?'))) {
    console.log('Cancelled.');
    return;
  }
  confirmed = true;
  await cmdUninstall();
  console.log('');
  await cmdInstall();
}

async function main() {
  const cmd = process.argv[2] || 'help';

  switch (cmd) {
    case 'install':
    case 'i':
      await cmdInstall();
      break;
    case 'uninstall':
    case 'remove':
      await cmdUninstall();
      break;
    case 'update':
    case 'upgrade':
      await cmdUpdate();
      break;
    case 'reinstall':
      await cmdReinstall();
      break;
    case 'status':
    case 'info':
      await cmdStatus();
      break;
    case 'help':
    case '--help':
    case '-h':
    default:
      console.log(BANNER);
      console.log('Usage: npx huaweicloud-devkit <command>\n');
      console.log('Commands:');
      console.log('  install      Install skills, MCP server, safety policy to OpenCode');
      console.log('  uninstall    Remove installed files');
      console.log('  update       Update to latest version');
      console.log('  reinstall    Full clean reinstall');
      console.log('  status       Show installation status');
      console.log('  help         Show this help');
      console.log('\nQuick install:');
      console.log('  npx huaweicloud-devkit install');
      break;
  }
}

main().catch((e) => {
  console.error(`\x1b[31mError: ${e.message}\x1b[0m`);
  process.exit(1);
});
